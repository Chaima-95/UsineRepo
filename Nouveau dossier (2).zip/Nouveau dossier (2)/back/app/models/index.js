/** @format */
const dbConfig = require("../config/db.config");
const mongoose = require("mongoose");
mongoose.Promise = global.Promise;

const db = {};

db.mongoose = mongoose;
db.user = require("./user.model");
db.role = require("./role.model");
db.alea = require("./alea.model");
db.product = require("./product.model")(mongoose);
db.hourSystem = require("./hourSystem.model");
db.line = require("./line.model");
db.personnel = require("./personnel.model");
db.zone = require("./zone.model");
db.product = require("./product.model");
db.ROLES = ["user", "admin", "superadmin"];

module.exports = db;
