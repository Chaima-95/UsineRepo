/** @format */

const mongoose = require("mongoose");
const HourSystem = mongoose.model(
  "HourSystem",
  new mongoose.Schema(
    {
      openingTime: {
        type: String,
        required: true,
        trim: true,
      },
      closureTime: {
        type: String,
        required: true,
        trim: true,
      },
      breakStartTime: {
        type: String,
        required: true,
        trim: true,
      },
      breakEndTime: {
        type: String,
        required: true,
        trim: true,
      },
      startDate: {
        type: String,
        // required: true,
        trim: true,
      },
      endDate: {
        type: String,
        // required: true,
        trim: true,
      },
    },
    { timestamps: true }
  )
);
new mongoose.Schema();
module.exports = HourSystem;
