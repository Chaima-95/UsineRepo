/** @format */

const mongoose = require("mongoose");
const User = mongoose.model(
  "User",
  new mongoose.Schema(
    {
      email: String,
      password: String,
      roles: [
        {
          type: mongoose.Schema.Types.Object,
          ref: "Role",
        },
      ],
    },
    { timestamps: true }
  )
);

module.exports = User;
