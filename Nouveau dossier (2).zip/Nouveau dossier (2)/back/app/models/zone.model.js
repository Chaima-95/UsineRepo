/** @format */

const mongoose = require("mongoose");
const Zone = mongoose.model(
  "Zone",
  new mongoose.Schema(
    {
      name: {
        type: String,
        // required: true,
        trim: true,
      },
      personnelNbr: {
        type: Number,
        // required: true,
        trim: true,
      },
      responsableName: {
        type: String,
        // required: true,
        trim: true,
      },
    },
    { timestamps: true }
  )
);

module.exports = Zone;
