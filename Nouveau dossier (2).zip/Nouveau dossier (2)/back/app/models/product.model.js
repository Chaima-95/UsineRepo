/** @format */

const mongoose = require("mongoose");
const Product = mongoose.model(
  "Product",
  new mongoose.Schema(
    {
      code: {
        type: String,
        required: true,
        trim: true,
      },
      name: {
        type: String,
        required: true,
        trim: true,
      },
      phase: {
        type: mongoose.Schema.Types.Object,
        ref: "Zone",
      },
      productionInHour: {
        type: Number,
        required: true,
        trim: true,
      },
      objectifInHour: {
        type: Number,
        trim: true,
      },
    },
    { timestamps: true }
  )
);

module.exports = Product;
