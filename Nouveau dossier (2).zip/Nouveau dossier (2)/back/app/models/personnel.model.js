/** @format */

const mongoose = require("mongoose");
const Personnel = mongoose.model(
  "Personnel",
  new mongoose.Schema(
    {
      matricule: {
        type: String,
        // required: true,
        trim: true,
      },
      name: {
        type: String,
        required: true,
        trim: true,
      },
      zone: {
        type: mongoose.Schema.Types.Object,
        ref: "Zone",
      },
    },
    { timestamps: true }
  )
);

module.exports = Personnel;
