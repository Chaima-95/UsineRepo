/** @format */

const mongoose = require("mongoose");
const Objectif = mongoose.model(
  "Objectif",
  new mongoose.Schema(
    {
      eeo: {
        type: Number,
        required: true,
        trim: true,
      },
      trs: {
        type: Number,
        required: true,
        trim: true,
      },
      tap: {
        type: Number,
        required: true,
        trim: true,
      },
    },
    { timestamps: true }
  )
);

module.exports = Objectif;
