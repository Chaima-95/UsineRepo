/** @format */
module.exports = (app) => {
  const production = require("../controllers/production.controller.js");
  var route = require("express").Router();

  route.post("/create", production.create);
  route.get("/getall", production.getall);
  route.get("/getbyid/:id", production.getbyid);
  route.get("/getbyname", production.getbyname);
  route.put("/update/:id", production.update);
  route.delete("/delete/:id", production.delete);
  app.use("/api/production", route);
};
