/** @format */
module.exports = (app) => {
  const zone = require("../controllers/zone.controller.js");
  var route = require("express").Router();

  route.post("/create", zone.create);
  route.get("/getall", zone.getall);
  route.get("/getbyid/:id", zone.getbyid);
  route.get("/getbyname", zone.getbyname);
  route.put("/update/:id", zone.update);
  route.delete("/delete/:id", zone.delete);
  app.use("/api/zone", route);
};
