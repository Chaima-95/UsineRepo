/** @format */

module.exports = (app) => {
  const roles = require("../controllers/role.controller.js");
  var router = require("express").Router();

  router.get("/", roles.findAll);
  router.get("/:id", roles.findOne);

  app.use("/api/roles", router);
};
