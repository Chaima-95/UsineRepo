/** @format */

const productionModel = require("../models/production.model");
module.exports = {
  create: async (req, res) => {
    const production = new productionModel(req.body);
    await production.save(req.body, (err, production) => {
      if (err) {
        res.status(406).json({
          success: false,
          message: "Failed to created production",
          data: null,
        });
        console.log(err);
      } else {
        res.status(201).json({
          success: true,
          message: "production Added successufly",
          data: production,
        });
      }
    });
  },
  getall: async (req, res) => {
    await productionModel.find({}).exec((err, items) => {
      if (err) {
        res
          .status(406)
          .json({ success: false, message: "Failed to get all productions" });
      } else {
        res.status(201).json({
          success: true,
          message: "List of productions",
          data: items,
        });
      }
    });
  },
  getbyid: async (req, res) => {
    await productionModel.findById(req.params.id).exec((err, item) => {
      if (err) {
        res
          .status(406)
          .json({ success: false, message: "Failed to get production" });
      } else {
        res
          .status(201)
          .json({ success: true, message: "production", data: item });
      }
    });
  },
  getbyname: async (req, res) => {
    await productionModel.find({ name: req.query.name }).exec((err, items) => {
      if (err) {
        res.status(406).json({
          success: false,
          message: "Failed to get  production by this name",
        });
      } else {
        res.status(201).json({
          success: true,
          message: "List of productions",
          data: items,
        });
      }
    });
  },
  update: async (req, res) => {
    await productionModel
      .findByIdAndUpdate(req.params.id, req.body, { new: true })
      .exec((err, item) => {
        if (err) {
          res
            .status(406)
            .json({ success: false, message: "Failed to update production" });
        } else {
          res.status(201).json({
            success: true,
            message: "production updated successfuly",
            data: item,
          });
        }
      });
  },
  delete: async (req, res) => {
    await productionModel
      .findByIdAndRemove(req.params.id)
      .exec((err, items) => {
        if (err) {
          res
            .status(406)
            .json({ success: false, message: "Failed to deleted production" });
        } else {
          res
            .status(201)
            .json({ success: true, message: "production deleted successfuly" });
        }
      });
  },
};
