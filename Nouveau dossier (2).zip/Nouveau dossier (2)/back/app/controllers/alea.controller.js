/** @format */

const aleaModel = require("../models/alea.model");
module.exports = {
  create: async (req, res) => {
    const alea = new aleaModel(req.body);
    await alea.save(req.body, (err, alea) => {
      if (err) {
        res.status(406).json({
          success: false,
          message: "Failed to created alea",
          data: null,
        });
        console.log(err);
      } else {
        res.status(201).json({
          success: true,
          message: "alea Added successufly",
          data: alea,
        });
      }
    });
  },
  getall: async (req, res) => {
    await aleaModel.find({}).exec((err, items) => {
      if (err) {
        res
          .status(406)
          .json({ success: false, message: "Failed to get all aleas" });
      } else {
        res.status(201).json({
          success: true,
          message: "List of aleas",
          data: items,
        });
      }
    });
  },
  getbyid: async (req, res) => {
    await aleaModel.findById(req.params.id).exec((err, item) => {
      if (err) {
        res.status(406).json({ success: false, message: "Failed to get alea" });
      } else {
        res.status(201).json({ success: true, message: "alea", data: item });
      }
    });
  },
  getbyname: async (req, res) => {
    await aleaModel.find({ name: req.query.name }).exec((err, items) => {
      if (err) {
        res.status(406).json({
          success: false,
          message: "Failed to get  alea by this name",
        });
      } else {
        res.status(201).json({
          success: true,
          message: "List of aleas",
          data: items,
        });
      }
    });
  },
  update: async (req, res) => {
    await aleaModel
      .findByIdAndUpdate(req.params.id, req.body, { new: true })
      .exec((err, item) => {
        if (err) {
          res
            .status(406)
            .json({ success: false, message: "Failed to update alea" });
        } else {
          res.status(201).json({
            success: true,
            message: "alea updated successfuly",
            data: item,
          });
        }
      });
  },
  delete: async (req, res) => {
    await aleaModel.findByIdAndRemove(req.params.id).exec((err, items) => {
      if (err) {
        res
          .status(406)
          .json({ success: false, message: "Failed to deleted alea" });
      } else {
        res
          .status(201)
          .json({ success: true, message: "alea deleted successfuly" });
      }
    });
  },
};
