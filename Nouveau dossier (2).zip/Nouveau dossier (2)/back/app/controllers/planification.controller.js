/** @format */

const planificationModel = require("../models/planification.model");
module.exports = {
  create: async (req, res) => {
    const planification = new planificationModel(req.body);
    await planification.save(req.body, (err, planification) => {
      if (err) {
        res.status(406).json({
          success: false,
          message: "Failed to created planification",
          data: null,
        });
        console.log(err);
      } else {
        res.status(201).json({
          success: true,
          message: "planification Added successufly",
          data: planification,
        });
      }
    });
  },
  getall: async (req, res) => {
    await planificationModel.find({}).exec((err, items) => {
      if (err) {
        res
          .status(406)
          .json({
            success: false,
            message: "Failed to get all planifications",
          });
      } else {
        res.status(201).json({
          success: true,
          message: "List of planifications",
          data: items,
        });
      }
    });
  },
  getbyid: async (req, res) => {
    await planificationModel.findById(req.params.id).exec((err, item) => {
      if (err) {
        res
          .status(406)
          .json({ success: false, message: "Failed to get planification" });
      } else {
        res
          .status(201)
          .json({ success: true, message: "planification", data: item });
      }
    });
  },
  getbyname: async (req, res) => {
    await planificationModel
      .find({ name: req.query.name })
      .exec((err, items) => {
        if (err) {
          res.status(406).json({
            success: false,
            message: "Failed to get  planification by this name",
          });
        } else {
          res.status(201).json({
            success: true,
            message: "List of planifications",
            data: items,
          });
        }
      });
  },
  update: async (req, res) => {
    await planificationModel
      .findByIdAndUpdate(req.params.id, req.body, { new: true })
      .exec((err, item) => {
        if (err) {
          res
            .status(406)
            .json({
              success: false,
              message: "Failed to update planification",
            });
        } else {
          res.status(201).json({
            success: true,
            message: "planification updated successfuly",
            data: item,
          });
        }
      });
  },
  delete: async (req, res) => {
    await planificationModel
      .findByIdAndRemove(req.params.id)
      .exec((err, items) => {
        if (err) {
          res
            .status(406)
            .json({
              success: false,
              message: "Failed to deleted planification",
            });
        } else {
          res
            .status(201)
            .json({
              success: true,
              message: "planification deleted successfuly",
            });
        }
      });
  },
};
