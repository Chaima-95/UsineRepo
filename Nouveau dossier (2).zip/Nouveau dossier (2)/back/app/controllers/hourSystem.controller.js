/** @format */

const hourSystemModel = require("../models/hourSystem.model");
module.exports = {
  create: async (req, res) => {
    const hourSystem = new hourSystemModel(req.body);
    await hourSystem.save(req.body, (err, hourSystem) => {
      if (err) {
        res.status(406).json({
          success: false,
          message: "Failed to created hourSystem",
          data: null,
        });
        console.log(err);
      } else {
        res.status(201).json({
          success: true,
          message: "hourSystem Added successufly",
          data: hourSystem,
        });
      }
    });
  },
  getall: async (req, res) => {
    await hourSystemModel.find({}).exec((err, items) => {
      if (err) {
        res
          .status(406)
          .json({ success: false, message: "Failed to get all hourSystems" });
      } else {
        res.status(201).json({
          success: true,
          message: "List of hourSystems",
          data: items,
        });
      }
    });
  },
  getbyid: async (req, res) => {
    await hourSystemModel.findById(req.params.id).exec((err, item) => {
      if (err) {
        res.status(406).json({ success: false, message: "Failed to get hourSystem" });
      } else {
        res.status(201).json({ success: true, message: "hourSystem", data: item });
      }
    });
  },
  getbyname: async (req, res) => {
    await hourSystemModel.find({ name: req.query.name }).exec((err, items) => {
      if (err) {
        res.status(406).json({
          success: false,
          message: "Failed to get  hourSystem by this name",
        });
      } else {
        res.status(201).json({
          success: true,
          message: "List of hourSystems",
          data: items,
        });
      }
    });
  },
  update: async (req, res) => {
    await hourSystemModel
      .findByIdAndUpdate(req.params.id, req.body, { new: true })
      .exec((err, item) => {
        if (err) {
          res
            .status(406)
            .json({ success: false, message: "Failed to update hourSystem" });
        } else {
          res.status(201).json({
            success: true,
            message: "hourSystem updated successfuly",
            data: item,
          });
        }
      });
  },
  delete: async (req, res) => {
    await hourSystemModel.findByIdAndRemove(req.params.id).exec((err, items) => {
      if (err) {
        res
          .status(406)
          .json({ success: false, message: "Failed to deleted hourSystem" });
      } else {
        res
          .status(201)
          .json({ success: true, message: "hourSystem deleted successfuly" });
      }
    });
  },
};
