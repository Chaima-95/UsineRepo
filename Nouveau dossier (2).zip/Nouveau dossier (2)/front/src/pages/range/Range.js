/** @format */

import React, { useEffect, useRef, useState } from "react";

import "react-datepicker/dist/react-datepicker.css";
import "antd/dist/antd.css";
import "../../components/range/range.css";
import "../../components/uap/uap's/Machines";
import Timepicker from "../../components/range/Timepicker";
import Objectifs from "../../components/range/Objectifs";
import Products from "../../components/range/tables/Products";
import Zones from "../../components/range/tables/Zones";
import Alea from "../../components/range/tables/Alea";

const Range = () => {
  const hour = [
    "Opening time",
    "Closure time",
    "Break start time",
    "Break end time",
  ];

  return (
    <div>
      <div className='container machines_container'>
        <div className='row machine_title'>
          <div className='col-md'>
            <h6>Establishment Time System</h6>
          </div>
        </div>
        <Timepicker num={1} systemHour={hour} />
        <div className='Separator' />
        <Timepicker num={2} />
        <div className='Separator' />
        <Timepicker num={3} />
      </div>
      {/**------------------- 2nd container----------------------- */}
      <div className='container machines_container'>
        <div className='row machine_title'>
          <div className='col-md'>
            <h6>Global Objectif</h6>
          </div>
        </div>
        <Objectifs />

        {/* <Objectifs objectifName={Name} /> */}
      </div>

      {/**------------------- 2nd container----------------------- */}
      <div className='container machines_container'>
        <div className='row machine_title'>
          <div className='col-md'>
            <h6>Produits</h6>
          </div>
        </div>
        <Products />
      </div>

      {/**------------------- 3rd container----------------------- */}
      <div className='container machines_container'>
        <div className='row machine_title'>
          <div className='col-md'>
            <h6>Zones</h6>
          </div>
          <Zones />
        </div>
        {/* <Articles columns={zoneCol} data={zones} /> */}
      </div>
      {/**------------------- 4th container----------------------- */}
      <div className='container machines_container'>
        <div className='row machine_title'>
          <div className='col-md'>
            <h6>Alea</h6>
          </div>
          <Alea />
        </div>
        {/* <Articles columns={aleaCol} data={aleas} /> */}
      </div>

      {/* *------------------- 3nd container-----------------------
      {title.map((item) => (
        <div className='container machines_container'>
          <div className='row machine_title'>
            <div className='col-md'>
              <h6>{item}</h6>
            </div>
          </div>
          <Table />
        </div>
      ))} */}
    </div>
  );
};

export default Range;
