/** @format */

import MaterialTable from "@material-table/core";
import React, { useEffect, useRef, useState } from "react";
import userData from "../../services/crud.service";
import isEmail from "validator/lib/isEmail";

const List = (props) => {
  const [columns, setColumns] = useState([
    { title: "Email", field: "email" },
    {
      title: "Roles",
      field: "roles",
      render: (rowData) => rowData.roles.map((item) => <div>{ item.name}</div>),
    },
  ]);
  const [iserror, setIserror] = useState(false);
  const [errorMessages, setErrorMessages] = useState([]);
  const [users, setUsers] = useState([]);
  const usersRef = useRef();
  usersRef.current = users;

  const retrieveUsers = () => {
    userData
      .getAll()
      .then((response) => {
        setUsers(response.data);
      })
      .catch((e) => {
        console.log(e);
      });
  };
  // ************ delete user *********** //
  const deleteUser = (oldData, resolve) => {
    userData
      .remove(oldData._id)
      .then((res) => {
        const index = oldData.tableData.id;
        let newUsers = [...usersRef.current];
        newUsers.splice(index, 1);
        setUsers(newUsers);
        resolve();
      })
      .catch((e) => {
        console.log(e);
        resolve();
      });
  };

  // ************ update user *********** //
  const updateUser = (newData, oldData, resolve) => {
    //validation
    let errorList = [];
    if (newData.email === undefined || !isEmail(newData.email) === false) {
      errorList.push("Please enter a valid email");
    }
    if (errorList.length < 1) {
      userData
        .update(newData._id, newData)
        .then((res) => {
          const dataUpdate = [...usersRef.current];
          const index = oldData.tableData.id;
          dataUpdate[index] = newData;
          setUsers([...dataUpdate]);
          resolve();
          setIserror(false);
          setErrorMessages([]);
        })
        .catch((error) => {
          setErrorMessages(["Update failed! Server error"]);
          setIserror(true);
          resolve();
        });
    } else {
      setErrorMessages(errorList);
      setIserror(true);
      resolve();
    }
  };

  useEffect(() => {
    retrieveUsers();
  }, []);
  console.log(users);
  return (
    <div className='container machines_container'>
      <div className='row machine_title'>
        <div className='col-md'>
          <h6>List of users</h6>
        </div>
      </div>
      <div className='row'>
        <div className='col-md'>
          <MaterialTable
            title=' '
            columns={columns}
            data={users}
            editable={{
              onRowUpdate: (newData, oldData) =>
                new Promise((resolve) => {
                  updateUser(newData, oldData, resolve);
                }),
              onRowDelete: (oldData) =>
                new Promise((resolve) => {
                  deleteUser(oldData, resolve);
                }),
            }}
          />
        </div>
      </div>
    </div>
  );
};

export default List;
