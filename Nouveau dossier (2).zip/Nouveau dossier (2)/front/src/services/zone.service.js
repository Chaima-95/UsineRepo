/** @format */
import axios from "axios";
import authHeader from "./auth-header";
const API_URL = "http://localhost:8082/api/zone";

const getAll = () => {
  return axios.get(`${API_URL}/getall`, { headers: authHeader() });
};
const getFiltredZones = (searchQuery) => {
  return axios.get(`${API_URL}/getall/?searchQuery=` + searchQuery);
};

const add = (data) => {
  return axios.post(API_URL + `/create/`, data, { headers: authHeader() });
};

const get = (id) => {
  return axios.get(`/${id}`, { headers: authHeader() });
};

const update = (id, data) => {
  return axios.put(API_URL + `/update/${id}`, data, { headers: authHeader() });
};
const remove = (id) => {
  return axios.delete(API_URL + `/delete/${id}`, { headers: authHeader() });
};

export default {
  getAll,
  add,
  remove,
  update,
  get,
  getFiltredZones,
};
