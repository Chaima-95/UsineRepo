/** @format */

import MaterialTable from "@material-table/core";
import React, { useEffect, useRef, useState } from "react";
import zoneData from "../../../services/zone.service";

const Zones = () => {
  const [zoneCol, setZoneCol] = useState([
    { title: " Name Zone", field: "name" },
    { title: "Responsable Name", field: "responsableName" },
    { title: "Number of persons", field: "personnelNbr" },
  ]);
  const [iserror, setIserror] = useState(false);
  const [errorMessages, setErrorMessages] = useState([]);
  const [zones, setZones] = useState([]);
  const zonesRef = useRef();
  zonesRef.current = zones;

  useEffect(() => {
    zoneData
      .getAll()
      .then((response) => {
        setZones(response.data.data);
        console.log(response.data.data);
      })
      .catch((e) => {
        console.log(e);
      });
  }, []);

  // ************ add article *********** //
  const addZone = (newData, resolve) => {
    console.log(newData);
    zoneData
      .add(newData)
      .then((res) => {
        const updatedRows = [...zonesRef.current, { ...newData }];
        setZones(updatedRows);
        resolve();
      })
      .catch((e) => {
        console.log(e);
        resolve();
      });
  };

  // ************ delete user *********** //
  const deleteZone = (oldData, resolve) => {
    zoneData
      .remove(oldData._id)
      .then((res) => {
        const index = oldData.tableData.id;
        let newZones = [...zonesRef.current];
        newZones.splice(index, 1);
        setZones(newZones);
        resolve();
      })
      .catch((e) => {
        console.log(e);
        resolve();
      });
  };

  // ************ update user *********** //
  const updateZone = (newData, oldData, resolve) => {
    //validation
    let errorList = [];
    // if (newData.email === undefined || !isEmail(newData.email) === false) {
    //   errorList.push("Please enter a valid email");
    // }

    // if (newData.personnelNbr === undefined || !newData.personnelNbr === false) {
    //   errorList.push("Please enter a nbr");
    //   console.log("error");
    // }
    if (errorList.length < 1) {
      zoneData
        .update(newData._id, newData)
        .then((res) => {
          const dataUpdate = [...zonesRef.current];
          const index = oldData.tableData.id;
          dataUpdate[index] = newData;
          setZones([...dataUpdate]);
          resolve();
          setIserror(false);
          setErrorMessages([]);
        })
        .catch((error) => {
          setErrorMessages(["Update failed! Server error"]);
          setIserror(true);
          resolve();
        });
    } else {
      setErrorMessages(errorList);
      setIserror(true);
      resolve();
    }
  };
  return (
    <MaterialTable
      title=' '
      columns={zoneCol}
      data={zones}
      editable={{
        onRowAdd: (newData) =>
          new Promise((resolve, reject) => {
            setTimeout(() => {
              addZone(newData, resolve);
            }, 2000);
          }),
        onRowDelete: (oldData) =>
          new Promise((resolve) => {
            deleteZone(oldData, resolve);
          }),
        onRowUpdate: (newData, oldData) =>
          new Promise((resolve) => {
            updateZone(newData, oldData, resolve);
        }),
      }}
    />
  );
};

export default Zones;
