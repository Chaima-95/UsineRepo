/** @format */

import React, { useState } from "react";

import "./range.css";
import { TimePicker } from "antd";
import { DatePicker, Space } from "antd";
import moment from "moment";
import timeData from "../../services/timeSystem.service";

const { RangePicker } = DatePicker;

const Timepicker = ({ num, systemHour }) => {
  const [checked, setChecked] = useState(true);
  const [openingTime, setopeningTime] = useState("");
  const [closureTime, setclosureTime] = useState("");
  const [breakstartTime, setBreakStartTime] = useState("");
  const [breakendTime, setBreakEndTime] = useState("");
  const [day, setDay] = useState("[]");

  const enable_Time = () => {
    setChecked(!checked);
  };

  const handleClick = () => {
    timeData
      .add({
        openingTime,
        closureTime,
        breakStartTime: breakstartTime,
        breakEndTime: breakendTime,
      })
      .then((res) => {
        console.log(res.data.data);
        console.log("success");
      })
      .catch((err) => {
        console.log(err);
      });
  };
  const format = "HH:mm";
  return (
    <div>
      <div className='time_system1'>
        {systemHour ? (
          <></>
        ) : (
          <input
            type='checkbox'
            onClick={enable_Time}
            style={{ marginRight: "5px" }}
          />
        )}
        Time System {num}
        <div className='row '>
          <div className='col-md-2 picker'>
            <label>Opening time </label>
            <TimePicker
              disabled={systemHour ? false : checked}
              size='large'
              format={format}
              placeholder='--:--'
              onChange={(openingTime, timeString) => {
                setopeningTime(timeString);
                console.log(openingTime);
              }}
            />
          </div>

          <div className='col-md-2 picker'>
            <label>Closure time </label>
            <TimePicker
              onChange={(closureTime, timeString) => {
                setclosureTime(timeString);
                console.log(closureTime);
              }}
              disabled={systemHour ? false : checked}
              size='large'
              format={"HH:mm"}
              placeholder='--:--'
            />
          </div>

          <div className='col-md-2 picker'>
            <label>Break start time </label>
            <TimePicker
              onChange={(breakstartTime, timeString) => {
                setBreakStartTime(timeString);
                console.log(breakstartTime);
              }}
              disabled={systemHour ? false : checked}
              size='large'
              format={"HH:mm"}
              placeholder='--:--'
            />
          </div>

          <div className='col-md-2 picker'>
            <label>Break end time </label>
            <TimePicker
              onChange={(breakendTime, timeString) => {
                setBreakEndTime(timeString);
                console.log(breakendTime);
              }}
              disabled={systemHour ? false : checked}
              size='large'
              format={"HH:mm"}
              placeholder='--:--'
            />
          </div>

          <div className='col-md-3 picker'>
            <label> days </label>
            <Space direction='vertical' size={12}>
              <RangePicker
                onChange={(day, dayString) => {
                  setDay(dayString);
                  console.log(dayString);
                }}
                format={"MMMM, DD"}
                size='large'
                disabled={systemHour ? false : checked}
              />
            </Space>
          </div>
          <div className='valid_button'>
            <button
              disabled={systemHour ? false : checked}
              className='btn btn-primary'
              onClick={handleClick}>
              Valider
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Timepicker;
