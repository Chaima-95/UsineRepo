/** @format */

import React, { useState } from "react";
import { Link } from "react-router-dom";
import GeneralVue from "./generalVue/GeneralVue";
import Uap from "./uap's/Uap";
import Planification from "./Planification";
import Production from "./Production";
const Header = () => {
  const [toggleButton1, settoggleButton1] = useState(true);
  const [toggleButton2, settoggleButton2] = useState(false);
  const [toggleButton3, settoggleButton3] = useState(false);
  const [toggleButton4, settoggleButton4] = useState(false);
  const showContent1 = () => {
    settoggleButton1(true);
    settoggleButton2(false);
    settoggleButton3(false);
    settoggleButton4(false);
  };
  const showContent2 = () => {
    settoggleButton2(true);
    settoggleButton1(false);
    settoggleButton3(false);
    settoggleButton4(false);
  };
  const showContent3 = () => {
    settoggleButton3(true);
    settoggleButton2(false);
    settoggleButton1(false);
    settoggleButton4(false);
  };
  const showContent4 = () => {
    settoggleButton4(true);
    settoggleButton2(false);
    settoggleButton3(false);
    settoggleButton1(false);
  };
  return (
    <div className='Uap_head'>
      <button
        type='button'
        className='btn1 btn btn-primary'
        onClick={showContent1}>
        <i className='fa fa-industry' />
        General vue
      </button>
      <button
        type='button'
        onClick={showContent2}
        className='btn1 btn btn-primary'>
        <i className='fa fa-list-ul' aria-hidden='true' />
        UAP's
      </button>
      <button
        type='button'
        onClick={showContent3}
        className='btn1 btn btn-primary'>
        <i className='fa fa-calendar-check-o' aria-hidden='true'></i>
        Planification
      </button>
      <button
        type='button'
        onClick={showContent4}
        className='btn1 btn btn-primary'>
        <i className='fa fa-product-hunt' aria-hidden='true'></i>Production
      </button>
      {toggleButton1 ? <GeneralVue /> : <></>}
      {toggleButton2 ? <Uap /> : <></>}
      {toggleButton3 ? <Planification /> : <></>}
      {toggleButton4 ? <Production /> : <></>}
    </div>
  );
};

export default Header;
