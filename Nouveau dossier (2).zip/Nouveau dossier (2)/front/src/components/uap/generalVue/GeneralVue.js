/** @format */

import React from "react";
import "../uap.css";
import Bottom from "./Bottom";
import Center from "./Center";

const GeneralVue = () => {
  return (
    <div>
      <Center />
      <Bottom />
    </div>
  );
};
export default GeneralVue;
