/** @format */

import React from "react";
import "./lights.css";
const Lights = (props) => {
  return (
    <div className='lights'>
      <div className='led-box'>
        {props.value < 60 ? (
          <div className='led-red' />
        ) : (
          <div className='led-no' />
        )}
      </div>
      <div className=' led-box'>
        {props.value < 60 ? (
          <div className='led-no' />
        ) : (
          <div className='led-yellow' />
        )}
      </div>
      <div className=' led-box'>
        {props.value < 80 ? (
          <div className='led-no' />
        ) : (
          <div className='led-green' />
        )}
      </div>
    </div>
  );
};

export default Lights;
