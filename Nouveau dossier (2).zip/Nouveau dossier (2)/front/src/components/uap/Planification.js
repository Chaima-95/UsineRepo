/** @format */

import React, { useEffect, useRef, useState } from "react";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import zoneService from "../../services/zone.service";
import lineService from "../../services/line.service";
import productService from "../../services/product.service";
import planService from "../../services/planification.service";

import "./filterStyle.css";
const Planification = () => {
  const [show, setShow] = useState(false);
  const [show1, setShow1] = useState(false);
  const [show2, setShow2] = useState(false);
  const [show3, setShow3] = useState(false);
  const [addLigne, setaddLigne] = useState([]);

  const handleClose = () => setShow(false);
  const handleClose1 = () => setShow1(false);
  const handleClose2 = () => {
    setShow2(false);
    setaddLigne([]);
  };
  const handleClose3 = () => setShow3(false);
  const handleShow = () => setShow(true);
  const handleShow1 = () => setShow1(true);
  const handleShow2 = () => setShow2(true);
  const handleShow3 = () => setShow3(true);

  const currentDate = new Date();
  const longMonth = currentDate.toLocaleString("en-us", { month: "long" });
  const firstday = new Date(
    currentDate.setDate(currentDate.getDate() - currentDate.getDay())
  );
  const lastday = new Date(
    currentDate.setDate(currentDate.getDate() - currentDate.getDay() + 7)
  );

  /****-----------------ADD ZONES--------------- */
  const [zone, setZone] = useState([]);
  const [plans, setPlans] = useState([]);
  const [lines, setLines] = useState([]);
  const [products, setProducts] = useState([]);
  const [zoneName, setZoneName] = useState("");
  const [responsbleName, setResponsbleName] = useState("");
  const [lineName, setLineName] = useState("");
  const [productName, setProductName] = useState("");
  const [phaseName, setPhaseName] = useState("");

  const [data, setData] = useState([]);
  const [singleData, setSingleData] = useState({
    lineName,
    product: {
      productName,
    },
    phaseName,
  });
  const addPlanZone = () => {
    planService
      .add({
        zone: {
          _id: JSON.parse(zoneName)._id,
          name: JSON.parse(zoneName).name,
          responsableName: JSON.parse(responsbleName).responsableName,
        },
        lines: [
          {
            _id: JSON.parse(lineName)._id,
            name: JSON.parse(lineName).name,
            phase: JSON.parse(phaseName).phase,
            product: {
              _id: JSON.parse(productName)._id,
              name: JSON.parse(productName).name,
            },
            // name: lineName,
            // phase: phaseName,
            // product: { name: productName },
          },
        ],
      })
      .then((res) => {
        console.log(res.data.data);
        console.log("success");
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handelLignes = () => {
    setaddLigne((array) => [
      ...array,
      // <>
      //   <hr />
      //   <Form.Group className='mb-3'>
      //     <Form.Label style={{ fontWeight: "500" }}>Nom de la ligne</Form.Label>
      //     <select
      //       className='form-control'
      //       onChange={(e) => (setSingleData.lineName = e.target.value)}
      //       style={{ height: "50%" }}>
      //       <option value=''></option>
      //       {lines.map((item, index) => {
      //         return (
      //           <option value={JSON.stringify(item)} key={index}>
      //             {item.name}
      //           </option>
      //         );
      //       })}
      //     </select>
      //   </Form.Group>
      //   <Form.Group>
      //     <Form.Label style={{ fontWeight: "500" }}>Nom du produit</Form.Label>
      //     <select
      //       className='form-control'
      //       onChange={(e) => console.log(e.target.value)}
      //       style={{ height: "50%" }}>
      //       <option value=''></option>
      //       {products.map((item, index) => {
      //         return (
      //           <option value={JSON.stringify(item)} key={index}>
      //             {item.name}
      //           </option>
      //         );
      //       })}
      //     </select>
      //   </Form.Group>
      //   <Form.Group>
      //     <Form.Label style={{ fontWeight: "500" }}>Phase</Form.Label>
      //     <select
      //       className='form-control'
      //       onChange={(e) => (setSingleData.phase = e.target.value)}
      //       style={{ height: "50%" }}>
      //       <option value=''></option>
      //       {lines.map((item, index) => {
      //         return (
      //           <option value={JSON.stringify(item)} key={index}>
      //             {item.phase}
      //           </option>
      //         );
      //       })}
      //     </select>
      //   </Form.Group>
      // </>,
    ]);
  };
  const getAllplans = () => {
    planService
      .getAll()
      .then((res) => {
        // console.log(res.data.data);
        setPlans(res.data.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };
  const updatePlans = () => {
    planService
      .update({})
      .then((res) => {
        // console.log(res.data.data);
        // setPlans(res.data.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };
  const getAllZones = () => {
    zoneService
      .getAll()
      .then((res) => {
        // console.log(res.data.data);
        setZone(res.data.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };
  const getAllProducts = () => {
    productService
      .getAll()
      .then((res) => {
        // console.log(res.data.data);
        setProducts(res.data.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const getAllLines = () => {
    lineService
      .getAll()
      .then((res) => {
        // console.log(res.data.data);
        setLines(res.data.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  useEffect(() => {
    getAllZones();
    getAllLines();
    getAllProducts();
    getAllplans();
  }, []);
  return (
    <div className='' style={{ border: "1px solid black" }}>
      <table
        style={{
          width: "100%",
          height: "80%",
          textAlign: "center",
          fontSize: "16px",
          fontWeight: " 400",
          color: "#6a6767",
          border: "1px solid black",
        }}>
        {/* 1st date  row*/}
        <tr style={{ border: "1px solid black", backgroundColor: " #EAF6FD" }}>
          <th style={{ width: "50%" }} colSpan='3'></th>
          <th
            style={{ width: " 50%", fontSize: "18px", padding: "4px" }}
            colSpan='5'>
            {longMonth} {firstday.getFullYear()}
          </th>
        </tr>
        {/* 2nd   row*/}
        <tr style={{ backgroundColor: " #fff" }}>
          <td>
            ZAP
            <Button
              style={{
                marginLeft: "10px",
                marginTop: "7px",
              }}
              onClick={handleShow2}
              variant='danger'>
              +zap
            </Button>
            <Modal show={show2} onHide={handleClose2}>
              <Modal.Header closeButton>
                <Modal.Title> Ajouter ZAP</Modal.Title>
              </Modal.Header>
              <Modal.Body>
                <Form.Group>
                  <Form.Label style={{ fontWeight: "500" }}>
                    Nom du nouveau ZAP
                  </Form.Label>
                  <select
                    className='form-control'
                    onChange={(e) => setZoneName(e.target.value)}
                    style={{ height: "50%" }}>
                    <option value=''></option>
                    {zone.map((item, index) => {
                      return (
                        <option value={JSON.stringify(item)} key={index}>
                          {item.name}
                        </option>
                      );
                    })}
                  </select>
                </Form.Group>
                <Form.Group>
                  <Form.Label style={{ fontWeight: "500" }}>
                    Nom du responsable ZAP
                  </Form.Label>
                  <select
                    className='form-control'
                    onChange={(e) => setResponsbleName(e.target.value)}
                    style={{ height: "50%" }}>
                    <option value=''></option>
                    {zone.map((item, index) => {
                      return (
                        <option value={JSON.stringify(item)} key={index}>
                          {item.responsableName}
                        </option>
                      );
                    })}
                  </select>
                </Form.Group>

                <hr />
                <Form.Group className='mb-3'>
                  <Form.Label style={{ fontWeight: "500" }}>
                    Nom de la ligne
                  </Form.Label>
                  <select
                    className='form-control'
                    onChange={(e) => setLineName(e.target.value)}
                    style={{ height: "50%" }}>
                    <option value=''></option>
                    {lines.map((item, index) => {
                      return (
                        <option value={JSON.stringify(item)} key={index}>
                          {item.name}
                        </option>
                      );
                    })}
                  </select>
                </Form.Group>
                <Form.Group>
                  <Form.Label style={{ fontWeight: "500" }}>
                    Nom du produit
                  </Form.Label>
                  <select
                    className='form-control'
                    // onChange={(e) => setProductName(e.target.value)}
                    style={{ height: "50%" }}>
                    <option value=''></option>
                    {products.map((item, index) => {
                      return (
                        <option value={JSON.stringify(item)} key={index}>
                          {item.name}
                        </option>
                      );
                    })}
                  </select>
                </Form.Group>
                <Form.Group>
                  <Form.Label style={{ fontWeight: "500" }}>Phase</Form.Label>
                  <select
                    className='form-control'
                    // onChange={(e) => setPhaseName(e.target.value)}
                    style={{ height: "50%" }}>
                    <option value=''></option>
                    {lines.map((item, index) => {
                      return (
                        <option value={JSON.stringify(item)} key={index}>
                          {item.phase}
                        </option>
                      );
                    })}
                  </select>
                </Form.Group>

                <Button
                  variant='btn btn-sm'
                  style={{
                    backgroundColor: "#E4E4E4",
                    borderColor: "#161E54",
                    textColor: "#161E54",
                    fontWeight: "700",
                  }}
                  onClick={handelLignes}>
                  + ligne
                </Button>
                {addLigne.map((item) => (
                  <>{item}</>
                ))}
              </Modal.Body>
              <Modal.Footer>
                <Button
                  variant='btn btn-primary btn-sm'
                  // onClick={addPlanZone}
                  onClick={() => console.log(lineName)}>
                  Ajouter ZAP
                </Button>
              </Modal.Footer>
            </Modal>
            <div>
              <input
                type='text'
                id='fname'
                name='fname'
                style={{ margin: "13px 0", width: "60%" }}
              />
            </div>
          </td>
          <td>
            Lignes
            <div>
              <input
                type='text'
                id='fname'
                name='fname'
                style={{ margin: "13px 0", width: "60%" }}
              />
            </div>
          </td>
          <td>
            Produit
            <div>
              <input
                type='text'
                id='fname'
                name='fname'
                style={{ margin: "13px 0", width: "60%" }}
              />
            </div>
          </td>
          <td>{firstday.getDate()}</td>
          <td>{firstday.getDate() + 1}</td>
          <td>{firstday.getDate() + 2}</td>
          <td>{firstday.getDate() + 3}</td>
          <td>{lastday.getDate()}</td>
        </tr>
      </table>
      {/*---------------------- 3rd Zone ADD  row--------------------------*/}
      {plans.map((item, index) => (
        <table
          style={{
            width: "100%",
            height: "80%",
            textAlign: "center",
            fontSize: "16px",
            fontWeight: " 400",
            color: "#6a6767",
            border: "1px solid black",
          }}>
          <tr style={{ backgroundColor: " #c5e7ffd9" }}>
            <td rowSpan='7'>
              <h5>{item.zone.name}</h5>
              Responsable: {item.zone.responsableName}
              {/* Modal of EDITER Button */}
              <br />
              <Button
                variant=' btn btn-outline-secondary'
                onClick={handleShow3}
                style={{
                  backgroundColor: "transparent",
                  borderColor: " #0d6efd",
                  color: "#0d6efd",
                  fontSize: "14px",
                  padding: "4px 18px",
                  margin: " 7px 7px",
                }}>
                <i className='fa fa-pencil-square-o' aria-hidden='true' />
                Editer
              </Button>
              <Modal show={show3} onHide={handleClose3}>
                <Modal.Header closeButton>
                  <Modal.Title>Editer ZAP "Insertion"</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                  <Form.Group className='mb-3'>
                    <Form.Label style={{ fontWeight: "500" }}>
                      Nom ZAP
                    </Form.Label>
                    <select className='form-control' style={{ height: "50%" }}>
                      <option value='' selected disabled hidden>
                        Choose here
                      </option>
                      {zone.map((item, index) => {
                        return (
                          <option value={JSON.stringify(item)} key={index}>
                            {item.name}
                          </option>
                        );
                      })}
                    </select>
                    <Form.Label style={{ fontWeight: "500" }}>
                      Nom du responsable
                    </Form.Label>
                    <Form.Control type='text' />
                    <hr />
                    <Form.Label style={{ fontWeight: "500" }}>
                      Nom de la ligne
                    </Form.Label>
                    <Form.Control type='text' />
                    <Form.Label style={{ fontWeight: "500" }}>
                      Nom du produit
                    </Form.Label>
                    <Form.Control type='text' />
                    <Form.Label style={{ fontWeight: "500" }}>Phase</Form.Label>
                    <Form.Control type='text' />
                    <br />
                    <Button
                      variant='btn btn-sm'
                      style={{
                        backgroundColor: "#E4E4E4",
                        borderColor: "#161E54",
                        textColor: "#161E54",
                        fontWeight: "700",
                      }}>
                      + ligne
                    </Button>
                  </Form.Group>
                </Modal.Body>
                <Modal.Footer>
                  <Button
                    variant='btn btn-danger btn-sm'
                    onClick={handleClose3}>
                    Supprimer la zone "Insertion"
                  </Button>
                  <Button variant='btn btn-light btn-sm' onClick={handleClose3}>
                    Save
                  </Button>
                </Modal.Footer>
              </Modal>
            </td>
          </tr>

          {item.lines.map((item, index) => (
            <tr>
              <td>
                Code:
                <br></br>
                {item.name}
                <br></br>
                <hr style={{ width: "80%", marginLeft: "20%" }} />
                Phase:
                <br></br>
                {item.product.phase.name}
              </td>
              <td>
                Produit: <br></br>
                {item.product.name}
                <br></br>
                Semaine/QCF:
                <br></br>
                1688/1000
                <br></br>
                {/* Modal of Planifier Button */}
                <Button
                  variant=' btn btn-outline-secondary'
                  onClick={handleShow1}
                  style={{
                    backgroundColor: "transparent",
                    borderColor: " #0d6efd",
                    color: "#0d6efd",
                    fontSize: "14px",
                    padding: "4px 18px",
                    margin: " 7px 7px",
                  }}>
                  <i className='fa fa-calendar-check-o' aria-hidden='true' />{" "}
                  Planifier
                </Button>
                <Modal show={show1} onHide={handleClose1}>
                  <Modal.Header closeButton>
                    <Modal.Title>Plan the goal of the week</Modal.Title>
                  </Modal.Header>
                  <Modal.Body>
                    <Form.Group className='mb-3'>
                      <Form.Label style={{ fontWeight: "500" }}>
                        Global quantity (QOF)
                      </Form.Label>
                      <Form.Control type='number' />

                      <Form.Check
                        style={{ fontWeight: "300" }}
                        type='checkbox'
                        label='Apply this QOF automatically to other lines with the same code "007896520".'
                      />
                    </Form.Group>
                  </Modal.Body>
                  <Modal.Footer>
                    <Button
                      variant='btn btn-primary btn-sm'
                      onClick={handleClose1}>
                      Close
                    </Button>
                    <Button
                      variant='btn btn-light btn-sm'
                      onClick={handleClose1}>
                      Save
                    </Button>
                  </Modal.Footer>
                </Modal>
              </td>
              {[1, 2, 3, 4, 5].map(() => (
                <td>
                  <table border='1' style={{ width: "100%", height: "100%" }}>
                    <tr>
                      <td>
                        {/* Modal of Planifié Icon */}
                        <i
                          className='fa fa-pencil-square-o'
                          aria-hidden='true'
                          onClick={handleShow}
                        />
                        <Modal show={show} onHide={handleClose}>
                          <Modal.Header closeButton>
                            <Modal.Title>
                              Définir la planification de 17 Mai 20022 de
                              produit "0502563RET" de la phase emballage
                            </Modal.Title>
                          </Modal.Header>
                          <Modal.Body>
                            <Form.Group className='mb-3'>
                              <Form.Label style={{ fontWeight: "500" }}>
                                Objectif planifié
                              </Form.Label>
                              <Form.Control type='number' />
                            </Form.Group>
                          </Modal.Body>
                          <Modal.Footer>
                            <Button variant='primary' onClick={handleClose}>
                              Sauvegarder
                            </Button>
                          </Modal.Footer>
                        </Modal>
                      </td>
                      <td>H</td>
                    </tr>
                    <tr>
                      <td>Production</td>
                      <td>J</td>
                    </tr>
                  </table>
                </td>
              ))}
            </tr>
          ))}
        </table>
      ))}
    </div>
  );
};

export default Planification;
