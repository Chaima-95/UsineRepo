/** @format */

import React, { useEffect, useState } from "react";
import { Input, InputNumber } from "antd";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import { height } from "@mui/system";

const Alert = () => {
  const { TextArea } = Input;
  const [show, setShow] = useState(false);

  const day = new Date();
  let minute = day.getMinutes("mm");
  useEffect(() => {
    if (minute + "" === "00") {
      window.onload = function () {
        if (!window.location.hash) {
          window.location = window.location + "#loaded";
          window.location.reload();
        }
      };
      console.log(minute);
      setShow(true);
    }
  }, [minute]);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  return (
    <div>
      <Button variant=' btn btn-outline-secondary' onClick={handleShow}>
        <i className='fa fa-bell' aria-hidden='true' /> Alert
      </Button>
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Hourly production notification</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <label style={{ fontWeight: "500" }}>
            Total number of produced pieces:
          </label>
          <input
            className='form-control'
            style={{ marginBottom: "6px" }}
            type='number'
          />
          {/* <InputNumber
            style={{
              width: "100%",
              color: "gray",
            }}
            defaultValue='Production'
            min='0'
            step='1'
          /> */}
          <select className='form-control' style={{ height: "40px" }}>
            <option>Select</option>
            <option value='1'>One</option>
            <option value='2'>Two</option>
            <option value='3'>Three</option>
          </select>
          <label style={{ fontWeight: "500" }}>Number of persons:</label>

          <input className='form-control' type='number'></input>

          <label style={{ fontWeight: "500" }}>
            Number of non-compliant pieces:
          </label>
          <input className='form-control' type='number'></input>

          <label style={{ fontWeight: "500" }}>Alea</label>
          <select
            className='form-control'
            defaultValue='Alea'
            style={{ height: "40px" }}>
            <option value='lucy1'>Alea</option>
            <option value='test2'>test2</option>
            <option value='test3'>test3</option>
          </select>
          <label style={{ fontWeight: "500" }}>Comment</label>
          <textArea
            className='form-control'
            rows={2.5}
            placeholder='Enter a comment'
          />
        </Modal.Body>
        <Modal.Footer>
          <Button variant='btn btn-primary btn-sm' onClick={handleClose}>
            Close
          </Button>
          <Button variant='btn btn-light btn-sm' onClick={handleClose}>
            Save
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default Alert;
